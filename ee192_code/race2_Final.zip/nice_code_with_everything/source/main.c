/*
 * The Clear BSD License
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*System includes.*/
#include <stdio.h>

#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"

/* Kernel includes. */
#include "FreeRTOS.h"
#include "timers.h"

/* Freescale includes. */
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "fsl_pit.h"  /* periodic interrupt timer */
#include "fsl_ftm.h"

#include "fsl_adc16.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DEMO_ADC16_BASEADDR ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL 12U /* PTB2, ADC0_SE12 */

#define DEMO_ADC16_IRQn ADC0_IRQn
#define DEMO_ADC16_IRQ_HANDLER_FUNC ADC0_IRQHandler

#define VREF_BRD 3.300
#define SE_12BIT 4096.0

// Defining camera GPIO pins for CLK (PTC12) and SI (PTD1)
#define GPIO_CHANNEL_C GPIOC
#define GPIO_CHANNEL_D GPIOD
#define GPIO_PIN_SI 1U
#define GPIO_PIN_CLK 12U
#define GPIO_PIN_PWM 4U

// Defining PIT0 stuff for global systime
#define PIT_IRQ_ID PIT0_IRQn
/* Get source clock for PIT driver */
#define PIT_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)

// Defining PIT1 stuff for camera reading and steering
#define PIT_IRQ_ID1 PIT1_IRQn
/* Get source clock for PIT driver */
#define PIT_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)

// FTM modules for motor and servo PWMs. PTD3 (motor) and PTC1 (servo).
#define BOARD_FTM_BASEADDR0 FTM0
#define BOARD_FTM_BASEADDR3 FTM3
#define BOARD_FTM_CHANNEL0 kFTM_Chnl_0
#define BOARD_FTM_CHANNEL3 kFTM_Chnl_3
/* Interrupt to enable and flag to read; depends on the FTM channel used */
#define FTM_CHANNEL_INTERRUPT_ENABLE kFTM_Chnl0InterruptEnable
#define FTM_CHANNEL_FLAG kFTM_Chnl0Flag
#define FTM_CHANNEL_INTERRUPT_ENABLE1 kFTM_Chnl1InterruptEnable
#define FTM_CHANNEL_FLAG1 kFTM_Chnl1Flag

/* Interrupt number and interrupt handler for the FTM instance used */
#define FTM_INTERRUPT_NUMBER FTM0_IRQn
#define FTM_0_HANDLER FTM0_IRQHandler

/* Get source clock for FTM driver */
#define FTM_SOURCE_CLOCK0 CLOCK_GetFreq(kCLOCK_BusClk)
#define FTM_SOURCE_CLOCK3 CLOCK_GetFreq(kCLOCK_BusClk)
//High Voltage(3.3V)=True for pwm
#define PWM_LEVEL kFTM_HighTrue


/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/* PWM functions for updating duty cycle of servo and motor. */
void update_duty_cycle(uint32_t freq_hz, uint8_t updated_duty_cycle);
void init_pwm_servo(uint32_t freq_hz, uint8_t init_duty_cycle);
void init_pwm_motor(uint32_t freq_hz, uint8_t init_duty_cycle);

/* Initialize ADC16 */
static void init_ADC(void);
static void init_board(void);
void read_ADC(void);

/* Camera reading functions. */
void take_pic(uint32_t condition, uint32_t exp_delay);
void camera_read(void);
void camera_exposure(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
// ADC variables
volatile bool g_Adc16ConversionDoneFlag = false;
volatile uint32_t g_Adc16ConversionValue = 0;
adc16_channel_config_t g_adc16ChannelConfigStruct;

// PIT global time variables (100U = 10,000 Hz)
volatile bool pitIsrFlag = false;
volatile uint32_t systime = 0; //systime updated very 100 us = 4 days ==> NEED OVERFLOW protection

// PIT1 timer - camera read, image analysis, steering (10000U = 100 Hz)
volatile bool pitIsrFlag1 = false;

// Camera variables
uint32_t camera[128];
uint32_t default_delay = 1; // Delay for "garbage" read; 10 = 1ms (b/c of 100U PIT)
volatile int exposure_delay; // Variable exposure delay for "good" read; 10 = 1ms (b/c of 100U PIT)
volatile float kp_exp = 1;
uint32_t line_threshold = 500; // Threshold to compare pixel values to, for determining argmax
int line_ct_thresh = 47;
int goal_avg = 200; // Avg for comparison to implement variable exposure
volatile int test_exp_error = 0;
volatile int act_avg = 0;
volatile int arg_max = 0;
volatile int line_width = 0;
int total_delay = 10;

// Line scanning algorithm variables
uint32_t center_value = 0;

// FTM variables
volatile bool ftmIsrFlag = false;
volatile uint8_t duty_cycle = 1U;

// Servo and motor variables
volatile int time;
volatile int prev_time;
uint32_t servo_freq = 250;
uint32_t motor_freq = 2500;
float motorPWM = 30;
float centerPWM = 37;
volatile int prev_center = 63; //previous arg_max
int set_center = 63; //set center
volatile float error = 0.;
volatile float prev_error = 0.;
volatile float error_sum = 0.;
volatile float kp = 0.12; // was 0.1
volatile float kd = 0.02; // was 0.2
volatile float ki = 0.0;


/*******************************************************************************
 * Code
 ******************************************************************************/
void set_SI_high(void){
	GPIO_PinWrite(GPIO_CHANNEL_D, GPIO_PIN_SI, 1); // Set SI high
}
void set_SI_low(void){
	GPIO_PinWrite(GPIO_CHANNEL_D, GPIO_PIN_SI, 0); // Set SI high
}
void set_CLK_high(void){
	GPIO_PinWrite(GPIO_CHANNEL_C, GPIO_PIN_CLK, 1); // Set SI high
}
void set_CLK_low(void){
	GPIO_PinWrite(GPIO_CHANNEL_C, GPIO_PIN_CLK, 0); // Set SI high
}

void init_board()
{
	// Configure an output pin with initial value 0
	gpio_pin_config_t gpio_config = {
				kGPIO_DigitalOutput, 0,
			};

	/* initialize GPIO Pin */
	GPIO_PinInit(GPIO_CHANNEL_D, GPIO_PIN_SI, &gpio_config); // initialize GPIOD pin PTD1
	GPIO_PinInit(GPIO_CHANNEL_C, GPIO_PIN_CLK, &gpio_config); // initialize GPIOC pin PTC12


	/* Board pin, clock, debug console init */
	BOARD_InitPins();
	BOARD_BootClockRUN();
	BOARD_InitDebugConsole();
}

static void init_ADC(void)
{
	EnableIRQ(DEMO_ADC16_IRQn);
    adc16_config_t adc16ConfigStruct;

    /* Configure the ADC16. */
    /*
     * adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceVref;
     * adc16ConfigStruct.clockSource = kADC16_ClockSourceAsynchronousClock;
     * adc16ConfigStruct.enableAsynchronousClock = true;
     * adc16ConfigStruct.clockDivider = kADC16_ClockDivider8;
     * adc16ConfigStruct.resolution = kADC16_ResolutionSE12Bit;
     * adc16ConfigStruct.longSampleMode = kADC16_LongSampleDisabled;
     * adc16ConfigStruct.enableHighSpeed = false;
     * adc16ConfigStruct.enableLowPower = false;
     * adc16ConfigStruct.enableContinuousConversion = false;
     */
    ADC16_GetDefaultConfig(&adc16ConfigStruct);
#if defined(BOARD_ADC_USE_ALT_VREF)
    adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
#endif
    ADC16_Init(DEMO_ADC16_BASEADDR, &adc16ConfigStruct);

    /* Make sure the software trigger is used. */
    ADC16_EnableHardwareTrigger(DEMO_ADC16_BASEADDR, false);
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASEADDR))
    {
        PRINTF("\r\nADC16_DoAutoCalibration() Done.");
    }
    else
    {
        PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
    }
#endif /* FSL_FEATURE_ADC16_HAS_CALIBRATION */

    /* Prepare ADC channel setting */
    g_adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL;
    g_adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = true;

#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
    g_adc16ChannelConfigStruct.enableDifferentialConversion = false;
#endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */
}

void read_ADC(void){
	g_Adc16ConversionDoneFlag = false;
	ADC16_SetChannelConfig(DEMO_ADC16_BASEADDR, DEMO_ADC16_CHANNEL_GROUP, &g_adc16ChannelConfigStruct);

	//Block until the ADC Conversion is finished
	 while (!g_Adc16ConversionDoneFlag)
	 {
	 }
}

// PIT-related functions

void init_PIT(void)
{
	// start periodic interrupt timer- should be in its own file
	pit_config_t pitConfig;
	PIT_GetDefaultConfig(&pitConfig);
	/* Init pit module */
	PIT_Init(PIT, &pitConfig);
	/* Set timer period for channel 0 */

	PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, USEC_TO_COUNT(100U, PIT_SOURCE_CLOCK)); // 100 us timing
	/* Enable timer interrupts for channel 0 */
	PIT_EnableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
	/* Enable at the NVIC */
	EnableIRQ(PIT_IRQ_ID);
	/* Start channel 0 */
	PRINTF("\r\nStarting channel No.0 ...");
	PIT_StartTimer(PIT, kPIT_Chnl_0);
}

void init_PIT1(void)
{
	// start periodic interrupt timer- should be in its own file
	pit_config_t pitConfig;
	PIT_GetDefaultConfig(&pitConfig);
	/* Init pit module */
	PIT_Init(PIT, &pitConfig);
	/* Set timer period for channel 1 */

	PIT_SetTimerPeriod(PIT, kPIT_Chnl_1, USEC_TO_COUNT(10000U, PIT_SOURCE_CLOCK)); // 10000 us, 100 Hz timing
	/* Enable timer interrupts for channel 1 */
	PIT_EnableInterrupts(PIT, kPIT_Chnl_1, kPIT_TimerInterruptEnable);
	/* Enable at the NVIC */
	EnableIRQ(PIT_IRQ_ID1);
	/* Start channel 1 */
	PRINTF("\r\nStarting channel No.1...");
	PIT_StartTimer(PIT, kPIT_Chnl_1);
}

// TIME-RELATED FUNCTIONS

/* Outputs the current time (i.e. the systime) */
uint32_t get_curr_time(){
	return systime;
}

/* Delay function that uses the global systime, set to increment every 100U. */
void delay(uint32_t t)
{
	uint32_t endTime;
	endTime = t + systime;
	while(systime < endTime) {
		continue;
	}
}

/* Dummy delay function that just runs a while loop. */
void dummy_delay(void)
{
    volatile uint32_t i = 0U;
    for (i = 0U; i < 80000U; ++i)
    {
        __asm("NOP"); /* delay */
    }
}

// FUNCTIONS FOR GETTING DATA FROM THE CAMERA

/* Performs the double read operation. Populates camera array with "good" image values. */
void camera_read() {
	take_pic(0, exposure_delay); // garbage read
	camera_exposure(); // calculates and applies the variable delay exposure
	take_pic(1, default_delay); // actual read, gets saved as camera array
}

/* Function to get data from camera. If cond = 1, data saved; If cond = 0, data not saved. */
void take_pic(uint32_t condition, uint32_t exp_delay){
	set_SI_high(); // SI high
	dummy_delay(); // dummy delay
	set_CLK_high(); //CLK high
	dummy_delay(); // dummy delay
	set_SI_low(); // SI low

	uint16_t k = 0;

	for(k=0; k < 128; k++){
		set_CLK_high();
		if (condition == 1) { // goes in here if the "good" read
			read_ADC();
			camera[k] = (int)(g_Adc16ConversionValue);
		}
		set_CLK_low();
	}
	delay(exp_delay);
}

/* Function for updating the average pixel value and arg max of camera array. */
void camera_avg_and_max() {
	int sum = 0;
	int max_ind = 0;
	for (int i = 0; i < 128; i++) {
		sum += (int) camera[i];
	if (camera[max_ind] < camera[i]){
		max_ind = i;
	}
	}
	act_avg = sum / 128;
	arg_max = max_ind;
}

/* Function for getting the line width. Threshold here is arbitrary. */
int line_pixel_width() {
	int num_pixels = 0;
	for (int i = 0; i < 128; i++) {
		if (camera[i] > line_threshold) {
			num_pixels += 1;
		}
	}
	return num_pixels;
}

/* Function that calculates the variable exposure delay based off past "good" camera read. */
void camera_exposure() {
	// Camera statistics
//	int avg = camera_avg();
	camera_avg_and_max(); //sets avg and arg max for camera array as global variables
	// Calculating error and computing the adjusted exposure
	int exp_error = goal_avg - act_avg; // If >0, then under-exposed. If <0, then over-exposed.
	test_exp_error = exp_error;
//	act_avg = avg;
	exposure_delay = exposure_delay + (int) (kp_exp * exp_error);

	// Limits to prevent extreme values, i.e. exposure doesn't go negative or too long.
	if (exposure_delay <= 0) {
		exposure_delay = 1;
	}
	if (exposure_delay >= 1000) {
		exposure_delay = 1000;
	}
}

/* Finds the line center. */
int find_center(uint32_t arr[]) {
	int left = find_left(camera);
	int right = find_right(camera);
	int center = (left + right) / 2;
	prev_center = center;
	return center;
}

/* Find the two indices of right and left edge. */
int find_center_from_max_diffs(uint32_t arr[]) {
	int ind_left = 0;
	int ind_right = 127;
	int a = 5;
	int i = 127;
	int line_ct = 0;
	camera_avg_and_max();
	while (a < 117) {
		if (arr[a] > act_avg * 5 / 3) {
			line_ct++;
		}

		int left_diff = arr[a + 6] - arr[a];
		int left_diff_old = arr[ind_left + 6] - arr[ind_left];
		if (left_diff_old < left_diff) {
			ind_left = a;
		}

		int right_diff = arr[i - 6] - arr[i];
		int right_diff_old = arr[ind_right - 6] - arr[ind_right];
		if (right_diff_old < right_diff) {
			ind_right = i;
		}
		i--;
		a++;
	}

	ind_left += 3;
	ind_right -= 3;

//	if (arr[ind_left + 6] - arr[ind_left] < 50) { // trying to account for left step
//		ind_left = 0;
//	}
//	if (arr[ind_right - 6] - arr[ind_right] < 50) { // trying to account for right step
//		ind_right = 127;
//	}

	int center = (ind_left + ind_right) / 2;

//	if (line_ct > line_ct_thresh && (ind_left != 0 || ind_right != 127)) {
//		center = prev_center;
//	}

	if (line_ct < 5) {
		center = prev_center;
	}

//	if (abs(center - prev_center) > 50) { //helps with crossings but makes steps worse
//		center = prev_center;
//	}
//	if (line_ct < 6 || ind_right < ind_left || abs(center - prev_center) > 80) {
//		center = prev_center;
//	}

	prev_center = center;
	return center;
}

/* Find the index of left edge. */
int find_left(uint32_t arr[]) {
	uint32_t maxIndex = 0;
	for (int i = 0; i < 122; ++i) {
		int diff = arr[i + 6] - arr[i];
		int old_diff = arr[maxIndex + 6] - arr[maxIndex];
	  if (old_diff < diff) {
		  maxIndex = i;
	  }
	}
	if (arr[maxIndex + 6] - arr[maxIndex] < 50) { // trying to account for left step
		return 0;
	}
	return maxIndex+3;
}

/* Find the index of right edge. */
int find_right(uint32_t arr[]) {
	uint32_t maxIndex = 127;
	for (int i = 127; i > 6; i--) {
		int diff = arr[i - 6] - arr[i];
		int old_diff= arr[maxIndex - 6] - arr[maxIndex];
	  if (old_diff < diff){
		  maxIndex = i;
	  }
    }
	if (arr[maxIndex - 6] - arr[maxIndex] < 50) { // trying to account for right step
		return 127;
	}
	return maxIndex-3;
}


// FUNCTIONS FOR SERVO AND MOTOR CONTROL

/*Initialize the Flexible Timer Module to Produce PWM with init_duty_cycle at freq_hz*/
void init_pwm_servo(uint32_t freq_hz, uint8_t init_duty_cycle)
{
	duty_cycle = init_duty_cycle;
    ftm_config_t ftmInfo;
    ftm_chnl_pwm_signal_param_t ftmParam;

    /* Configure ftm params with for pwm freq- freq_hz, duty cycle- init_duty_cycle */
    ftmParam.chnlNumber = BOARD_FTM_CHANNEL0;
    ftmParam.level = PWM_LEVEL;
    ftmParam.dutyCyclePercent = init_duty_cycle;
    ftmParam.firstEdgeDelayPercent = 0U;

    FTM_GetDefaultConfig(&ftmInfo);
    ftmInfo.prescale = kFTM_Prescale_Divide_128; //needed for low freq
    /* Initialize FTM module */
    FTM_Init(BOARD_FTM_BASEADDR0, &ftmInfo);

    FTM_SetupPwm(BOARD_FTM_BASEADDR0, &ftmParam, 1U, kFTM_CenterAlignedPwm, freq_hz, FTM_SOURCE_CLOCK0);

    /* Enable channel interrupt flag.*/
    //FTM_EnableInterrupts(BOARD_FTM_BASEADDR0, FTM_CHANNEL_INTERRUPT_ENABLE);

    /* Enable at the NVIC */
    //EnableIRQ(FTM_INTERRUPT_NUMBER);

    FTM_StartTimer(BOARD_FTM_BASEADDR0, kFTM_SystemClock);
}

void init_pwm_motor(uint32_t freq_hz, uint8_t init_duty_cycle)
{
	duty_cycle = init_duty_cycle;
    ftm_config_t ftmInfo;
    ftm_chnl_pwm_signal_param_t ftmParam;

    /* Configure ftm params with for pwm freq- freq_hz, duty cycle- init_duty_cycle */
    ftmParam.chnlNumber = BOARD_FTM_CHANNEL3;
    ftmParam.level = PWM_LEVEL;
    ftmParam.dutyCyclePercent = init_duty_cycle;
    ftmParam.firstEdgeDelayPercent = 0U;

    FTM_GetDefaultConfig(&ftmInfo);
    ftmInfo.prescale = kFTM_Prescale_Divide_1; //needed for low freq
    /* Initialize FTM module */
    FTM_Init(BOARD_FTM_BASEADDR3, &ftmInfo);

    FTM_SetupPwm(BOARD_FTM_BASEADDR3, &ftmParam, 1U, kFTM_CenterAlignedPwm, freq_hz, FTM_SOURCE_CLOCK3);

    /* Enable channel interrupt flag.*/
    //FTM_EnableInterrupts(BOARD_FTM_BASEADDR0, FTM_CHANNEL_INTERRUPT_ENABLE);

    /* Enable at the NVIC */
    //EnableIRQ(FTM_INTERRUPT_NUMBER);

    FTM_StartTimer(BOARD_FTM_BASEADDR3, kFTM_SystemClock);
}

void update_duty_cycle_servo(float updated_duty_cycle, float centerPWM)
{
	uint8_t input;
	//float u = updated_duty_cycle - centerPWM;
	if (updated_duty_cycle < centerPWM * 0.33) { //hard limits

		input = (uint8_t) (centerPWM * 0.33 + 0.5);
	}
	else if (updated_duty_cycle > centerPWM * 1.67 ) {//hard limits
		input = (uint8_t) (centerPWM *1.67 + 0.5);
	}
	else {
		input = (uint8_t) (updated_duty_cycle + 0.5);
	}

	//FTM_DisableInterrupts(BOARD_FTM_BASEADDR0, FTM_CHANNEL_INTERRUPT_ENABLE);

	/* Disable channel output before updating the dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(BOARD_FTM_BASEADDR0, BOARD_FTM_CHANNEL0, 0U);

	/* Update PWM duty cycle */
	FTM_UpdatePwmDutycycle(BOARD_FTM_BASEADDR0, BOARD_FTM_CHANNEL0, kFTM_CenterAlignedPwm, input);

	/* Software trigger to update registers */
	FTM_SetSoftwareTrigger(BOARD_FTM_BASEADDR0, true);

	/* Start channel output with updated dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(BOARD_FTM_BASEADDR0, BOARD_FTM_CHANNEL0, PWM_LEVEL);

	/* Delay to view the updated PWM dutycycle */
	//delay(); //Can be removed when using PWM for realtime applications

	/* Enable interrupt flag to update PWM dutycycle */
	//FTM_EnableInterrupts(BOARD_FTM_BASEADDR0, FTM_CHANNEL_INTERRUPT_ENABLE);
}

void update_duty_cycle_motor(float updated_duty_cycle)
{
	uint8_t input;
	if (updated_duty_cycle <0.0) {
		input = 0;
	}
	else if (updated_duty_cycle > 30.0) {
		input = 30;
	}
	else {
		input = (uint8_t) updated_duty_cycle;
	}

	//FTM_DisableInterrupts(BOARD_FTM_BASEADDR0, FTM_CHANNEL_INTERRUPT_ENABLE);

	/* Disable channel output before updating the dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(BOARD_FTM_BASEADDR3, BOARD_FTM_CHANNEL3, 0U);

	/* Update PWM duty cycle */
	FTM_UpdatePwmDutycycle(BOARD_FTM_BASEADDR3, BOARD_FTM_CHANNEL3, kFTM_CenterAlignedPwm, input);

	/* Software trigger to update registers */
	FTM_SetSoftwareTrigger(BOARD_FTM_BASEADDR3, true);

	/* Start channel output with updated dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(BOARD_FTM_BASEADDR3, BOARD_FTM_CHANNEL3, PWM_LEVEL);

	/* Delay to view the updated PWM dutycycle */
	//delay(); //Can be removed when using PWM for realtime applications

	/* Enable interrupt flag to update PWM dutycycle */
	//FTM_EnableInterrupts(BOARD_FTM_BASEADDR0, FTM_CHANNEL_INTERRUPT_ENABLE);
}

void apply_steering(void) {
//		 Steering control
		int center = find_center_from_max_diffs(camera);
		center_value = camera[center];
		error = (float) (set_center - center); //should be a float; for kp
		uint32_t dt = time - prev_time;
		float error_d = (error - prev_error) / dt; // for kd
		error_sum += error; // for ki
		prev_time = time;
		prev_error = error;
		//float u = (kp*error); //ki = 0
		float u = (kp*error + kd*error_d); //pd control
		update_duty_cycle_servo(centerPWM + u, centerPWM);
}


/*!
 * @brief Main function
 */
int main(void)
{
	time = 0;
    init_board();
    init_ADC();
    init_PIT();
//    init_PIT1();
    init_pwm_servo(servo_freq, centerPWM);
    delay(20000); // delay 2 seconds

    for (int n = 0; n < 15; n++) {
		time = get_curr_time();
    	camera_read();
		apply_steering();
    }

    init_pwm_motor(motor_freq, 16); // works for 17 and 18... 19 is unstable
	while (1)
	{
		time = get_curr_time();
		camera_read();
		apply_steering();
		if (total_delay - exposure_delay < 0) {
			delay(1);
		}
		else{
			delay(total_delay - exposure_delay);
		}
	}

}

// FUNCTIONS DOING PIT STUFF

void PIT0_IRQHandler(void)
{
	systime++; /* hopefully atomic operation */
	PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
	pitIsrFlag = true;
    /* Clear interrupt flag.*/
}

//void PIT1_IRQHandler(void)
//{
//	camera_read(); // a double exposure based camera read function. Must be fast.
//	PIT_ClearStatusFlags(PIT, kPIT_Chnl_1, kPIT_TimerFlag);
//	pitIsrFlag1 = true;
//    /* Clear interrupt flag.*/
//}

// FUNCTIONS DOING ADC STUFF

void DEMO_ADC16_IRQ_HANDLER_FUNC(void)
{
    g_Adc16ConversionDoneFlag = true;
    /* Read conversion result to clear the conversion completed flag. */
    g_Adc16ConversionValue = ADC16_GetChannelConversionValue(DEMO_ADC16_BASEADDR, DEMO_ADC16_CHANNEL_GROUP);
    /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
      exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U)
    __DSB();
#endif
}
